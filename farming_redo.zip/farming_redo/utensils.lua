
local S = farming.intllib

-- wooden bowl

minetest.register_craftitem("farming_redo:bowl", {
	description = ("Wooden Bowl"),
	inventory_image = "farming_bowl.png",
	groups = {food_bowl = 1, flammable = 2},
})

minetest.register_craft({
	output = "farming_redo:bowl 4",
	recipe = {
		{"group:wood", "", "group:wood"},
		{"", "group:wood", ""},
	}
})

minetest.register_craft({
	type = "fuel",
	recipe = "farming_redo:bowl",
	burntime = 10,
})

-- saucepan

minetest.register_craftitem("farming_redo:saucepan", {
	description = ("Saucepan"),
	inventory_image = "farming_saucepan.png",
	groups = {food_saucepan = 1, flammable = 2},
})

minetest.register_craft({
	output = "farming_redo:saucepan",
	recipe = {
		{"default:steel_ingot", "", ""},
		{"", "group:stick", ""},
	}
})

-- cooking pot

minetest.register_craftitem("farming_redo:pot", {
	description = ("Cooking Pot"),
	inventory_image = "farming_pot.png",
	groups = {food_pot = 1, flammable = 2},
})

minetest.register_craft({
	output = "farming_redo:pot",
	recipe = {
		{"group:stick", "default:steel_ingot", "default:steel_ingot"},
		{"", "default:steel_ingot", "default:steel_ingot"},
	}
})

-- baking tray

minetest.register_craftitem("farming_redo:baking_tray", {
	description = ("Baking Tray"),
	inventory_image = "farming_baking_tray.png",
	groups = {food_baking_tray = 1, flammable = 2},
})

minetest.register_craft({
	output = "farming_redo:baking_tray",
	recipe = {
		{"default:clay_brick", "default:clay_brick", "default:clay_brick"},
		{"default:clay_brick", "", "default:clay_brick"},
		{"default:clay_brick", "default:clay_brick", "default:clay_brick"},
	}
})

-- skillet

minetest.register_craftitem("farming_redo:skillet", {
	description = ("Skillet"),
	inventory_image = "farming_skillet.png",
	groups = {food_skillet = 1, flammable = 2},
})

minetest.register_craft({
	output = "farming_redo:skillet",
	recipe = {
		{"default:steel_ingot", "", ""},
		{"", "default:steel_ingot", ""},
		{"", "", "group:stick"},
	}
})

-- mortar and pestle

minetest.register_craftitem("farming_redo:mortar_pestle", {
	description = ("Mortar and Pestle"),
	inventory_image = "farming_mortar_pestle.png",
	groups = {food_mortar_pestle = 1, flammable = 2},
})

minetest.register_craft({
	output = "farming_redo:mortar_pestle",
	recipe = {
		{"default:stone", "group:stick", "default:stone"},
		{"", "default:stone", ""},
	}
})

-- cutting board

minetest.register_craftitem("farming_redo:cutting_board", {
	description = ("Cutting Board"),
	inventory_image = "farming_cutting_board.png",
	groups = {food_cutting_board = 1, flammable = 2},
})

minetest.register_craft({
	output = "farming_redo:cutting_board",
	recipe = {
		{"default:steel_ingot", "", ""},
		{"", "group:stick", ""},
		{"", "", "group:wood"},
	}
})

-- juicer

minetest.register_craftitem("farming_redo:juicer", {
	description = ("Juicer"),
	inventory_image = "farming_juicer.png",
	groups = {food_juicer = 1, flammable = 2},
})

minetest.register_craft({
	output = "farming_redo:juicer",
	recipe = {
		{"", "default:stone", ""},
		{"default:stone", "", "default:stone"},
	}
})

-- glass mixing bowl

minetest.register_craftitem("farming_redo:mixing_bowl", {
	description = ("Glass Mixing Bowl"),
	inventory_image = "farming_mixing_bowl.png",
	groups = {food_mixing_bowl = 1, flammable = 2},
})

minetest.register_craft({
	output = "farming_redo:mixing_bowl",
	recipe = {
		{"default:glass", "group:stick", "default:glass"},
		{"", "default:glass", ""},
	}
})

minetest.register_craft( {
	type = "shapeless",
	output = "vessels:glass_fragments",
	recipe = {
		"farming_redo:mixing_bowl",
	},
})

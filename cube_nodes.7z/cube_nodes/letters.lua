--NODES USE ASCII NUMBERS FOR SYMBOLS!
--ASCII NUMBER FOR "A" IS "065".
minetest.register_craft({
	output = "cube_nodes:node_A",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_6", "cube_nodes:number_5"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_B",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_6", "cube_nodes:number_6"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_C",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_6", "cube_nodes:number_7"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_D",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_6", "cube_nodes:number_8"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_E",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_6", "cube_nodes:number_9"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_F",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_7", "cube_nodes:number_0"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_G",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_7", "cube_nodes:number_1"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_H",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_7", "cube_nodes:number_2"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_I",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_7", "cube_nodes:number_3"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_J",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_7", "cube_nodes:number_4"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_K",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_7", "cube_nodes:number_5"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_L",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_7", "cube_nodes:number_6"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_M",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_7", "cube_nodes:number_7"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_N",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_7", "cube_nodes:number_8"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_O",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_7", "cube_nodes:number_9"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_P",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_8", "cube_nodes:number_0"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_Q",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_8", "cube_nodes:number_1"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_R",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_8", "cube_nodes:number_2"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_S",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_8", "cube_nodes:number_3"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_T",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_8", "cube_nodes:number_4"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_U",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_8", "cube_nodes:number_5"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_V",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_8", "cube_nodes:number_6"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_W",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_8", "cube_nodes:number_7"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_X",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_8", "cube_nodes:number_8"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_Y",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_8", "cube_nodes:number_9"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:node_Z",
	recipe = {
		{"cube_nodes:number_0", "cube_nodes:number_9", "cube_nodes:number_0"},
		{"", "", ""},
		{"", "", ""},
	}
})

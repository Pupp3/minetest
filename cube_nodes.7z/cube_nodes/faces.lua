minetest.register_craft({
	output = "cube_nodes:face_smile",
	recipe = {
		{"cube_nodes:number_6", "cube_nodes:number_6", "cube_nodes:number_6"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:face_sad",
	recipe = {
		{"cube_nodes:number_6", "cube_nodes:number_6", "cube_nodes:number_7"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:face_normal",
	recipe = {
		{"cube_nodes:number_6", "cube_nodes:number_6", "cube_nodes:number_8"},
		{"", "", ""},
		{"", "", ""},
	}
})

minetest.register_craft({
	output = "cube_nodes:face_angry",
	recipe = {
		{"cube_nodes:number_6", "cube_nodes:number_6", "cube_nodes:number_9"},
		{"", "", ""},
		{"", "", ""},
	}
})

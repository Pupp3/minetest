minetest.register_craft({
	output = "cube_nodes:number_0",
	recipe = {
		{"dye:black", "dye:white", "dye:white"},
		{"dye:white", "dye:white", "dye:white"},
		{"dye:white", "dye:white", "group:wood"},
	}
})

minetest.register_craft({
	output = "cube_nodes:number_1",
	recipe = {
		{"dye:black", "dye:black", "dye:white"},
		{"dye:white", "dye:white", "dye:white"},
		{"dye:white", "dye:white", "group:wood"},
	}
})

minetest.register_craft({
	output = "cube_nodes:number_2",
	recipe = {
		{"dye:black", "dye:black", "dye:black"},
		{"dye:white", "dye:white", "dye:white"},
		{"dye:white", "dye:white", "group:wood"},
	}
})

minetest.register_craft({
	output = "cube_nodes:number_3",
	recipe = {
		{"dye:black", "dye:black", "dye:black"},
		{"dye:black", "dye:white", "dye:white"},
		{"dye:white", "dye:white", "group:wood"},
	}
})

minetest.register_craft({
	output = "cube_nodes:number_4",
	recipe = {
		{"dye:black", "dye:black", "dye:black"},
		{"dye:black", "dye:black", "dye:white"},
		{"dye:white", "dye:white", "group:wood"},
	}
})

minetest.register_craft({
	output = "cube_nodes:number_5",
	recipe = {
		{"dye:black", "dye:black", "dye:black"},
		{"dye:black", "dye:black", "dye:black"},
		{"dye:white", "dye:white", "group:wood"},
	}
})

minetest.register_craft({
	output = "cube_nodes:number_6",
	recipe = {
		{"dye:black", "dye:black", "dye:black"},
		{"dye:black", "dye:black", "dye:black"},
		{"dye:black", "dye:white", "group:wood"},
	}
})

minetest.register_craft({
	output = "cube_nodes:number_7",
	recipe = {
		{"dye:black", "dye:black", "dye:black"},
		{"dye:black", "dye:black", "dye:black"},
		{"dye:black", "dye:black", "group:wood"},
	}
})

minetest.register_craft({
	output = "cube_nodes:number_8",
	recipe = {
		{"dye:white", "dye:white", "dye:white"},
		{"dye:white", "dye:white", "dye:white"},
		{"dye:white", "dye:white", "group:wood"},
	}
})

minetest.register_craft({
	output = "cube_nodes:number_9",
	recipe = {
		{"dye:black", "dye:white", "dye:white"},
		{"dye:white", "dye:black", "dye:white"},
		{"dye:white", "dye:white", "group:wood"},
	}
})

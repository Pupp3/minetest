![horror](screenshot.png)

# horror

Minetest mod that adds horror themed blocks, materials, mobs and other assets.

![](https://github.com/D00Med/horror/workflows/luacheck/badge.svg)


# Attributions

See: `license.txt`

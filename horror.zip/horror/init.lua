--other files
if minetest.get_modpath("mobs") then
dofile(minetest.get_modpath("horror").."/mobs.lua")
end
horror = {} --needed for functions
dofile(minetest.get_modpath("horror").."/crafts.lua")
dofile(minetest.get_modpath("horror").."/tools.lua")
dofile(minetest.get_modpath("horror").."/functions.lua")
dofile(minetest.get_modpath("horror").."/nodes.lua")


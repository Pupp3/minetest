--EFFECTS ARE REGISTERED HERE
horror = {} -- NEEDED FOR FUNCTIONS
local weird_text = false --STRANGE TEXT
local sky = false --CHANGE THE COLOUR OF THE SKY
local flint = true --CHANGE FLINT OF STEEL WITH NEW VERSION
local hud = false --ADD TO THE SCREEN A HORROR HUD
--flint and steel override(not included in the license since it's only changing the node placed)
if flint == true then
if minetest.registered_items["fire:flint_and_steel"] then
minetest.override_item("fire:flint_and_steel", {
	description = "Flint and Steel",
	inventory_image = "fire_flint_steel.png",
	on_use = function(itemstack, user, pointed_thing)
		local player_name = user:get_player_name()
		local pt = pointed_thing

		if pt.type == "node" and minetest.get_node(pt.above).name == "air" then
			itemstack:add_wear(14)
			local node_under = minetest.get_node(pt.under).name

			if minetest.get_item_group(node_under, "flammable") >= 1 then
				if not minetest.is_protected(pt.above, player_name) then
					minetest.set_node(pt.above, {name = "horror:fire"})
				else
					minetest.chat_send_player(player_name, "This area is protected")
				end
			end
		end

		if not minetest.setting_getbool("creative_mode") then
			return itemstack
		end
	end
})
end
end

minetest.register_globalstep(function()
	if math.random(1,1000) == 1 and weird_text then
		local sound = math.random(1,7)
		minetest.sound_play(sound,
		{gain = 0.4, max_hear_distance = 1, loop = false})
	end

	if weird_text and math.random(1, 10000) == 1 then
		if math.random(1,4) == 1 then
			minetest.request_shutdown("bye bye!",false)
		else
			minetest.chat_send_all(". _*____")
			minetest.chat_send_all(".|    ::;  | ")
			minetest.chat_send_all(".|Oo  oO|")
			minetest.chat_send_all(". | ||' |")
			minetest.chat_send_all(".  |#||| ")
			minetest.chat_send_all(". _*____")
			minetest.chat_send_all(".|    ::;  | ")
			minetest.chat_send_all(".|Oo  oO|")
			minetest.chat_send_all(". | ||' |")
			minetest.chat_send_all(".  |#||| ")
			minetest.chat_send_all(". _*____")
			minetest.chat_send_all(".|    ::;  | ")
			minetest.chat_send_all(".|Oo  oO|")
			minetest.chat_send_all(". | ||' |")
			minetest.chat_send_all(".  |#||| ")
			minetest.chat_send_all(". _*____")
			minetest.chat_send_all(".|    ::;  | ")
			minetest.chat_send_all(".|Oo  oO|")
			minetest.chat_send_all(". | ||' |")
			minetest.chat_send_all(".  |#||| ")
			minetest.chat_send_all(". _*____")
			minetest.chat_send_all(".|    ::;  | ")
			minetest.chat_send_all(".|Oo  oO|")
			minetest.chat_send_all(". | ||' |")
			minetest.chat_send_all(".  |#||| ")
		end
	end
end)

--CHANGE COLOR OF THE SKY
if sky == true then
minetest.register_on_joinplayer(function(player)
minetest.after(0,function()
--player:override_day_night_ratio(0.41)
player:set_sky({r=40, g=0, b=40}, "plain")
end)
end)
end

--ADD TO THE HUD (SCREEN)
if hud == true then
minetest.register_on_joinplayer(function(player)
	minetest.after(0,function()
player:hud_add({
hud_elem_type = "image",
position = {x = 0.5, y = 0.5},
scale = {
x = -100,
y = -100
},
text = "horror_hud.png"
})
	--	player:hud_add({
	--	hud_elem_type = "image",
	--	position = {x = 0.5, y = 0.5},
	--	scale = {
	--	x = -50,
	--	y = -100
	--	},
	--	text = "horror_pentagram.png"
	--	})
end)
end)
end

--DROP HEAD ON DEATH
--minetest.register_on_dieplayer(function(player)
--	local pos = player:getpos();
--	minetest.add_item(pos, "horror:sam_head")
--end)

--ABMS
local punch_entities = {}
punch_entities["horror:ghost"] = true
punch_entities["horror:centipede"] = true
punch_entities["horror:spider"] = true
punch_entities["horror:demon"] = true
punch_entities["horror:pinky"] = true
punch_entities["horror:skull"] = true
punch_entities["horror:mancubus"] = true
punch_entities["horror:manticore"] = true
punch_entities["horror:shadow"] = true
punch_entities["horror:cacodemon"] = true
punch_entities["horror:mogall"] = true
--punch_entities["creatures:zombie"] = true

--SUNORB TURNS INTO GLOWORB
minetest.register_abm({
	nodenames = {"horror:sunorb", "horror:gloworb"},
	interval = 5,
	chance = 1,
	action = function(pos)
		local objs = minetest.get_objects_inside_radius({x=pos.x,y=pos.y,z=pos.z}, 5)
			for _, obj in pairs(objs) do
				if obj:get_luaentity() ~= nil then
					local ent = obj:get_luaentity().name
					if punch_entities[ent] then
						obj:punch(obj, 0.5, {
							full_punch_interval=0.5,
							damage_groups={fleshy=4},
						}, nil)
					end
				end
			end
	end
})

--GREEN FIRE
--IF YOU DISABLE THIS WITH MOBS ENABLED, APPEARS JUST FIRE INSTEAD DEMONS
minetest.register_abm({
	nodenames = {"horror:gfire"},
	interval = 5,
	chance = 1,
	action = function(pos)
		minetest.remove_node(pos)
	end
})

minetest.register_abm({
	nodenames = {"horror:fire"},
	interval = 1,
	chance = 2,
	action = function(pos)
		minetest.add_particlespawner({
			amount = 30,
			time = 4,
			minpos = {x=pos.x-0.5, y=pos.y, z=pos.z-0.5},
			maxpos = {x=pos.x+0.5, y=pos.y+1, z=pos.z+0.5},
			minvel = {x=-0.1, y=0.5, z=-0.1},
			maxvel = {x=0.1, y=0.5, z=0.1},
			minacc = {x=0, y=0, z=0},
			maxacc = {x=0, y=0, z=0},
			minexptime = 0.5,
			maxexptime = 0.5,
			minsize = 0.1,
			maxsize = 0.5,
			collisiondetection = false,
			texture = "horror_smoke.png"
		})
	end
})

minetest.register_abm({
	nodenames = {"horror:lantern"},
	interval = 1,
	chance = 2,
	action = function(pos)
		minetest.add_particlespawner({
			amount = 10,
			time = 4,
			minpos = {x=pos.x-0.5, y=pos.y-0.5, z=pos.z-0.5},
			maxpos = {x=pos.x+0.5, y=pos.y+0.5, z=pos.z+0.5},
			minvel = {x=-0.1, y=-0.1, z=-0.1},
			maxvel = {x=0.1, y=0.1, z=0.1},
			minacc = {x=0, y=0, z=0},
			maxacc = {x=0, y=0, z=0},
			minexptime = 1,
			maxexptime = 2,
			minsize = 1,
			maxsize = 2,
			collisiondetection = false,
			texture = "horror_fly.png"
		})
	end
})

minetest.register_abm({
	nodenames = {"horror:fountain"},
	interval = 1,
	chance = 2,
	action = function(pos)
		minetest.add_particlespawner({
			amount = 59,
			time = 4,
			minpos = {x=pos.x+0.1, y=pos.y-0.1, z=pos.z},
			maxpos = {x=pos.x+0.1, y=pos.y-0.1, z=pos.z},
			minvel = {x=0, y=-1, z=0},
			maxvel = {x=0, y=-2, z=0},
			minacc = {x=0, y=0, z=0},
			maxacc = {x=0, y=0, z=0},
			minexptime = 0.5,
			maxexptime = 1,
			minsize = 2,
			maxsize = 3,
			collisiondetection = false,
			texture = "horror_gunk.png"
		})
	end
})

--FLAMES ARE USELESS WITHOUT THIS
minetest.register_abm({
	nodenames = {"horror:flames"},
	interval = 3,
	chance = 1,
	action = function(pos)
		minetest.add_particlespawner({
			amount = 70,
			time = 4,
			minpos = {x=pos.x-0.2, y=pos.y-0.5, z=pos.z-0.2},
			maxpos = {x=pos.x+0.2, y=pos.y-0.5, z=pos.z+0.2},
			minvel = {x=0, y=0.7, z=0},
			maxvel = {x=0, y=0.9, z=0},
			minacc = {x=0, y=0, z=0},
			maxacc = {x=0, y=0, z=0},
			minexptime = 0.2,
			maxexptime = 0.5,
			minsize = 2,
			maxsize = 3,
			collisiondetection = false,
			texture = "horror_flame.png"
		})
	end
})

minetest.register_abm({
	nodenames = {"horror:head"},
	interval = 2,
	chance = 5,
	action = function(pos)
		minetest.add_particlespawner({
			amount = 2,
			time = 4,
			minpos = {x=pos.x-0.2, y=pos.y-0.2, z=pos.z-0.1},
			maxpos = {x=pos.x+0.2, y=pos.y-0.2, z=pos.z+0.1},
			minvel = {x=0, y=-0.7, z=0},
			maxvel = {x=0, y=-0.8, z=0},
			minacc = {x=0, y=-1, z=0},
			maxacc = {x=0, y=-1, z=0},
			minexptime = 4,
			maxexptime = 5,
			minsize = 1,
			maxsize = 2,
			collisiondetection = false,
			texture = "horror_blood.png"
		})
	end
})

minetest.register_abm({
	nodenames = {"horror:clock"},
	interval = 1.0,
	chance = 1,
	action = function(pos)
		minetest.sound_play("clock",
		{gain = 3, max_hear_distance = 1, loop = false})
		local meta = minetest.get_meta(pos)
		local time1 = minetest.get_timeofday()--*24000
		meta:set_string("infotext", "time:"..time1)
		if math.random(1,50000) then
		minetest.sound_play("clock_strikes_twelve",
		{gain = 1, max_hear_distance = 1, loop = false})
		end
	end
})

minetest.register_abm({
	nodenames = {"horror:roach_spawner"},
	interval = 2,
	chance = 2,
	action = function(pos)
		minetest.add_particlespawner({
			amount = 10,
			time = 4,
			minpos = {x=pos.x+0.2, y=pos.y-0.2, z=pos.z},
			maxpos = {x=pos.x+0.2, y=pos.y-0.2, z=pos.z},
			minvel = {x=-0.5, y=0, z=-0.5},
			maxvel = {x=0.5, y=0, z=0.5},
			minacc = {x=0, y=-1, z=0},
			maxacc = {x=0, y=-1, z=0},
			minexptime = 8,
			maxexptime = 10,
			minsize = 2,
			maxsize = 3,
			collisiondetection = true,
			texture = "horror_roach.png"
		})
	end
})

minetest.register_abm({
	nodenames = {"horror:cactus"},
	interval = 10,
	chance = 150,
	action = function(pos)
		local num = math.random(1,4)
		if minetest.get_node({x=pos.x, y=pos.y-1, z=pos.z}).name == "air" or
			minetest.get_node({x=pos.x, y=pos.y-1, z=pos.z}).name == "horror:cactus" then
			minetest.env:set_node({x=pos.x, y=pos.y-1, z=pos.z}, {name="horror:cactus"})
			minetest.env:remove_node(pos)
		end
		if num == 1 then
			if minetest.get_node({x=pos.x-2, y=pos.y, z=pos.z}).name == "air" then
				minetest.env:set_node({x=pos.x-2, y=pos.y, z=pos.z}, {name="horror:cactus"})
			end
		elseif num == 2 then
			if minetest.get_node({x=pos.x+2, y=pos.y, z=pos.z}).name == "air" then
				minetest.env:set_node({x=pos.x+2, y=pos.y, z=pos.z}, {name="horror:cactus"})
			end
		elseif num == 3 then
			if minetest.get_node({x=pos.x, y=pos.y, z=pos.z-2}).name == "air" then
				minetest.env:set_node({x=pos.x, y=pos.y, z=pos.z-2}, {name="horror:cactus"})
			end
		elseif num == 4 then
			if minetest.get_node({x=pos.x, y=pos.y, z=pos.z+2}).name == "air" then
				minetest.env:set_node({x=pos.x, y=pos.y, z=pos.z+2}, {name="horror:cactus"})
			end
		end
	end
})

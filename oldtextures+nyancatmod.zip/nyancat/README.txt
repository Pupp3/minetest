Minetest mod: nyancat
=====================
Replacement for the now removed Minetest Game "nyancat" mod.
Note that the Nyancat (and thus the media files) might be subject to trademark claims.
It is strongly recommend to use this mod exclusively for non-commercial activity.

Authors of source code
----------------------
Originally by celeron55, Perttu Ahola <celeron55@gmail.com> (LGPL 2.1)
Various Minetest developers and contributors (LGPL 2.1)

Authors of media files
----------------------
VanessaE (CC BY-SA 3.0):
  nyancat_front.png
  nyancat_back.png
  nyancat_side.png
  nyancat_rainbow.png
